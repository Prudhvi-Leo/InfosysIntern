package com.issuetracker.test;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.service.IssueService;
import com.issuetracker.service.IssueServiceImpl;

// Do Not Change Any Signature
public class IssueServiceTest
{
    private IssueService issueService = new IssueServiceImpl();

    public void reportAnIssueValidTest() throws IssueTrackerException
    {
	// Your Code Goes Here
    }

    public void reportAnIssueInvalidReportedDateTest()
    {
	// Your Code Goes Here
    }

    public void reportAnIssueInvalidStatusTest()
    {
	// Your Code Goes Here
    }

    public void reportAnIssueDuplicateIssueIdTest()
    {
	// Your Code Goes Here
    }
}