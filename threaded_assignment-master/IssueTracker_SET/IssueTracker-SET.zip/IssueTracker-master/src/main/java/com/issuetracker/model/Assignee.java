package com.issuetracker.model;

// Do Not Change Any Signature
public class Assignee
{
    // Your Code Goes Here
}