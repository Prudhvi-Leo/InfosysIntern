package com.issuetracker.model;

// Do Not Change Any Signature
public class IssueReport
{
    // Your Code Goes Here
}