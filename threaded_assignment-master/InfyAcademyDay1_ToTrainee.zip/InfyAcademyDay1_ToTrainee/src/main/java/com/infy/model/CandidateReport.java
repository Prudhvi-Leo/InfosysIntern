package com.infy.model;
//Follow the class diagram strictly
public class CandidateReport {
	
}
