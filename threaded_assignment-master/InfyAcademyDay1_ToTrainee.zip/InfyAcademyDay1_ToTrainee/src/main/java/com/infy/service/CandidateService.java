package com.infy.service;

import com.infy.model.Candidate;
import com.infy.model.CandidateReport;

public class CandidateService {

	// can have status as 'P' only if all 3 marks are 50 and above
	public String addCandidate(Candidate candidate) {
		return null;
	}

	// calculating grade for candidate based on his marks and result
	public String calculateGrade(CandidateReport candidateReportTO) {
		return null;
	}

	// populating map<CandidateId, Grade> by calling
	// calculateGrade(candidateReportTO) and returning the same.
	public String[] getGradesForAllCandidates() {
		return null;
	}
}
