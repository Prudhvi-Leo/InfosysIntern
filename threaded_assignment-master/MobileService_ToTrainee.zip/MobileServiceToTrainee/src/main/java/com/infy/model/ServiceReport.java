package com.infy.model;

public class ServiceReport {
	//your code goes here
}
