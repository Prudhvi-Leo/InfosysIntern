package com.issuetracker.test;



import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.service.IssueService;
import com.issuetracker.service.IssueServiceImpl;

public class IssueServiceTest
{
    private IssueService issueService = new IssueServiceImpl();

    
    public void reportAnIssueValidTest() throws IssueTrackerException
    {
	
    }

   
    public void reportAnIssueInvalidReportedDateTest()
    {
	
    }

    
    public void reportAnIssueInvalidStatusTest()
    {
	
    }

    
    public void reportAnIssueDuplicateIssueIdTest()
    {
	
    }
}