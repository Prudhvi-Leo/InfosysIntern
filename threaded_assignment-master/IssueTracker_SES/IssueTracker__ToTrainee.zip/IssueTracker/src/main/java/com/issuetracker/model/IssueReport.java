package com.issuetracker.model;

public class IssueReport
{
   
}