package com.issuetracker.userinterface;

import org.apache.commons.configuration2.ex.ConfigurationException;

import com.issuetracker.service.IssueService;
import com.issuetracker.service.IssueServiceImpl;

public class IssueTester
{
    private static IssueService issueService;

    public static void main(String[] args) throws ConfigurationException
    {
	issueService = new IssueServiceImpl();
	// Implement ExecutorService to invoke all the functionalities

	// Shutdown ExecutorService
    }
}
