package com.issuetracker.model;

public enum Unit
{
    ADMINISTRATION,
    CONSIGNMENT,
    PAYMENT,
    SHIPMENT
}