package com.issuetracker.service;

import java.util.List;

import com.issuetracker.model.Assignee;
import com.issuetracker.model.Unit;

public interface AssigneeService
{
    /**
     * Fetches the assignees list for the given unit
     * 
     * @param unit
     *        The assignee unit
     * 
     * @return The list of assignee objects fetched
     */
    public abstract List<Assignee> fetchAssignee(Unit unit);

    /**
     * Updates the active issues count for the given assignee email, by
     * incrementing or decrementing it based on the operation code
     * 
     * @param assigneeEmail
     *        The assignee email id
     * 
     * @param operation
     *        The operation code
     */
    public abstract void updateActiveIssueCount(String assigneeEmail,
						Character operation);
}