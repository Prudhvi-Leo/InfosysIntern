package com.issuetracker.validator;

import java.time.LocalDate;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueStatus;

public class Validator
{
    public void validate(Issue issue) throws IssueTrackerException
    {
	//Your code goes here
    }

    public Boolean isValidIssueId(String issueId)
    {
	return null;

    }

    public Boolean isValidIssueDescription(String issueDescription)
    {
	return null;
    }

    public Boolean isValidReportedOn(LocalDate reportedOn)
    {
	return null;
    }

    public Boolean isValidStatus(IssueStatus status)
    {
	return null;
    }
}