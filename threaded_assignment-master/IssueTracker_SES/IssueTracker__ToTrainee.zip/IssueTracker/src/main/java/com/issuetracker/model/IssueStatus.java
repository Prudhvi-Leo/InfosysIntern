package com.issuetracker.model;

public enum IssueStatus
{
   
}