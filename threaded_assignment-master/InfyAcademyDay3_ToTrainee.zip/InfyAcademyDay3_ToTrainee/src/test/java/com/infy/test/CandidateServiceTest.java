package com.infy.test;

public class CandidateServiceTest {
	//Coming real soon!!
}
