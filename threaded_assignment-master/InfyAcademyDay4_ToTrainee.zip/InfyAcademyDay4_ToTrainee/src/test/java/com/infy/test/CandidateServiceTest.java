package com.infy.test;

public class CandidateServiceTest {
	//Almost there! Coming soon!!
}
